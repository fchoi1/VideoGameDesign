Fabio Choi
fchoi30@gatech.edu
fchoi30
-----------------------

Changes along side the default roll a ball project:

Movement:
- add drag movement with mouse to control player along with default WASD movement
 - Mouse and keyboard movement both work
- increased AI speed and decreased player speed for higher difficulty

Environment:
- Added ramps
- increased play area with more obstacles
- scattered collectibles
- added collectibles on secondary level
- added more dynamic obstacles
